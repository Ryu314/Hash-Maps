/*
 * hashNode.cpp
 *
 *  Created on: Nov 11, 2018
 *      Author: Roger Yu
 */
#include "hashNode.hpp"
#include <iostream>
using namespace std;
hashNode::hashNode(){
	keyword = "";
	valuesSize = 0;
	currSize = 0;
	values = NULL;
}

hashNode::hashNode(string s){
	keyword = s;
	valuesSize = 100;
	currSize = 0;
	values = new string[valuesSize];
}

hashNode::hashNode(string s, string v){
	keyword = s;
	valuesSize = 100;
	currSize = 1;
	values = new string[valuesSize];
	values[0] = v;
}

void hashNode::addValue(string v){
	values[currSize] = v;
	currSize++;
}

void hashNode::dblArray(){
	string *temp = new string[valuesSize*2];
	for(int i = 0; i < valuesSize; i++){
		temp[i] = values[i];
	}
	values = temp;
}

string hashNode::getRandValue(){
	int i = rand() % valuesSize;
	return values[i];
}



