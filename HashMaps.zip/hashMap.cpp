/*
 * hashMap.cpp
 *
 *  Created on: Nov 15, 2018
 *      Author: Roger Yu
 */
#include "hashMap.hpp"
#include "hashNode.hpp"
#include <iostream>
using namespace std;

hashMap::hashMap(bool hash1, bool coll1){
	string first = NULL;
	int numKeys = 0;
	int mapSize = 13;
	bool h1 = hash1;
	bool c1 = coll1;
	int collisionct1 = 0;
	int collisionct2 = 0;
	map = new hashNode*[mapSize];
	map = NULL;
}

void hashMap::addKeyValue(string k, string v){
	int i = getIndex(k);
	if(numKeys/(double)mapSize > 0.7){
		reHash();
	}
	if(h1){
		collHash1(i, k);
	}
	else{
		collHash2(i, k);
	}

	if(map[i] == NULL){
		map[i] = new hashNode(k,v);
	}
	else{
		int i = map[i]->currSize;
		map[i]->values[i] = v;
	}
}

int hashMap::getIndex(string k){
	if(h1){
		return calcHash(k);
	}
	else{
		return calcHash2(k);
	}
}

int hashMap::calcHash(string k){
	int i = 0;
	for(int i = 0; i < 3; i++){
		i += int(k[i]);
	}
	i = i % mapSize;
	return i; //find first 3 letters of key and set them to integers, mod by mapSize
}

int hashMap::calcHash2(string k){
	int i = 0;
	for(int i = 0; i < 4; i++){
		i += int(k[i]);
	}
	i = i % mapSize;
	return i; //find first 4 letters of key and set them to integers, mod by mapSize
}

void hashMap::getClosestPrime(int primes[]){
	int i = mapSize * 2;
	int n = 0;
	while(primes[n] < i){
		n++;
	}
	mapSize = primes[n];
}

void hashMap::reHash(){
	int primes[24] = {2,3,5,7,11,13,17,23,27,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97};
	getClosestPrime(primes);
	int i = mapSize;
	hashNode **temp = new hashNode*[i];
	for(int i = 0; i < mapSize; i++){
		temp[i] = map[i];
	}
	map = temp;
}

int hashMap::collHash1(int i, string k){
	while(map[i]->keyword != k && map[i] != NULL){
		i = i+1;
		collisionct1++;
	}
	return i; //linear probing
}

int hashMap::collHash2(int i, string k){
	int count = 1;
	while(map[i]->keyword != k && map[i] != NULL){
		i = i + (count^2);
		count++;
		collisionct2++;
	}
	return i; //quadratic probing
}

int hashMap::findKey(string k){
	int key;
	if(h1){
		key = calcHash(k);
	}
	else{
		key = calcHash2(k);
	}
	return key;
}

void hashMap::printMap(){

}

