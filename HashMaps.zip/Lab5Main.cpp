/*
 * Lab5Main.cpp
 *
 *  Created on: Nov 20, 2018
 *      Author: Roger Yu
 */
#include <iostream>
#include "hashMap.hpp"
#include "hashNode.hpp"
#include "makeSeuss.hpp"
using namespace std;

int main(){
	srand(5);
	makeSeuss *m1 = new makeSeuss("DrSeuss.txt", "Output1.txt", true, true);
	makeSeuss *m2 = new makeSeuss("DrSeuss.txt", "Output2.txt", true, false);
	makeSeuss *m3 = new makeSeuss("DrSeuss.txt", "Output3.txt", false, true);
	makeSeuss *m4 = new makeSeuss("DrSeuss.txt", "Output4.txt", true, false);
	return 0;
}


